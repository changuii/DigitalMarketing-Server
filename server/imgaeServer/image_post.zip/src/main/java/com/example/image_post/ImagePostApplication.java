package com.example.image_post;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImagePostApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImagePostApplication.class, args);
	}

}
