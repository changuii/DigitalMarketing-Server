package com.example.image_post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImagePostApplicationTests {

	@Test
	void contextLoads() {
	}

}
